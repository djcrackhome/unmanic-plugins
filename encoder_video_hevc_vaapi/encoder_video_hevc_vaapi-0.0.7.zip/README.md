# Video Encoder H265/HEVC - hevc_vaapi

plugin for [Unmanic](https://github.com/Unmanic)
