# Audio Encoder AAC

plugin for [Unmanic](https://github.com/Unmanic)
