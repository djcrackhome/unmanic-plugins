# Video Encoder H264 - libx264

plugin for [Unmanic](https://github.com/Unmanic)
