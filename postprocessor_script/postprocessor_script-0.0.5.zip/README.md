# External Post-processor Script

plugin for [Unmanic](https://github.com/Unmanic)
